package com.guh.fortniteafkmanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080D18)
private val Panel = Color(0xFF121D30)
private val Blue = Color(0xFF36A7FF)
private val Muted = Color(0xFF9AAAC0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FortniteApp() }
    }
}

@Composable
fun FortniteApp() {
    var tab by remember { mutableIntStateOf(0) }
    val titles = listOf("Dashboard", "Configurações", "Recompensas", "Discord", "Histórico")
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Blue, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    val icons = listOf(Icons.Default.Dashboard, Icons.Default.Tune,
                        Icons.Default.CardGiftcard, Icons.Default.Send, Icons.Default.History)
                    titles.forEachIndexed { i, title ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(icons[i], contentDescription = title) },
                            label = { Text(title, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Text("FORTNITE", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(titles[tab], color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(14.dp))
                when (tab) {
                    0 -> DashboardScreen()
                    1 -> SettingsScreen()
                    2 -> RewardsScreen()
                    3 -> DiscordScreen()
                    else -> HistoryScreen()
                }
            }
        }
    }
}

@Composable
fun PanelCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp), content = {
            Text(title, color = Blue, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            content()
        })
    }
}

@Composable
fun DashboardScreen() {
    val context = LocalContext.current
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        PanelCard("Status do companion") {
            Text("Monitoramento local pronto", color = Color.White)
            Text("O app não controla o Fortnite nem executa toques automáticos.", color = Muted)
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                if (!Settings.canDrawOverlays(context)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}"))
                    context.startActivity(intent)
                } else {
                    context.startService(Intent(context, OverlayService::class.java))
                }
            }) { Text("Ativar mini painel") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Partidas", "0", Modifier.weight(1f))
            StatCard("Recompensas", "0", Modifier.weight(1f))
        }
        PanelCard("Squad") {
            Text("Jogador 1: Desconhecido", color = Muted)
            Text("Jogador 2: Desconhecido", color = Muted)
            Text("Jogador 3: Desconhecido", color = Muted)
            Text("Jogador 4: Desconhecido", color = Muted)
            Text("O estado do squad ainda precisa ser informado manualmente.", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, color = Muted)
            Text(value, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen() {
    var games by remember { mutableStateOf("10") }
    var duration by remember { mutableStateOf("15 minutos") }
    var wait by remember { mutableStateOf("40") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        PanelCard("Limite de partidas") {
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded, { expanded = it }) {
                OutlinedTextField(games, { games = it }, readOnly = true,
                    label = { Text("Quantidade") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded, { expanded = false }) {
                    listOf("10", "20", "50", "100", "Infinitas").forEach {
                        DropdownMenuItem(text = { Text(it) }, onClick = { games = it; expanded = false })
                    }
                }
            }
        }
        PanelCard("Temporizador por partida") {
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded, { expanded = it }) {
                OutlinedTextField(duration, { duration = it }, readOnly = true,
                    label = { Text("Duração") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded, { expanded = false }) {
                    listOf("5 minutos", "10 minutos", "15 minutos", "20 minutos", "30 minutos", "Sem limite").forEach {
                        DropdownMenuItem(text = { Text(it) }, onClick = { duration = it; expanded = false })
                    }
                }
            }
        }
        PanelCard("Intervalo entre partidas") {
            OutlinedTextField(wait, { wait = it.filter(Char::isDigit) },
                label = { Text("Segundos (ex.: 40)") }, modifier = Modifier.fillMaxWidth())
            Text("Configuração para controle e lembrete; não inicia partidas automaticamente.", color = Muted, fontSize = 12.sp)
        }
    }
}

private val rewardNames = listOf(
    "Solid Gold A\\$AP Rocky",
    "Solid Gold A\\$AP Rocky Gauntlets",
    "No Trespassing",
    "Plunder in Paradise",
    "Mercedes-AMG G 63 'G-Wagon'",
    "Golden Llama Crew",
    "Pirate Shop Access (2026)",
    "Pirate Shop Access (2027)",
    "Extraction Accelerator",
    "Portable Extractor",
    "Golden Firework",
    "Sprite Locator",
    "Lucky Locator",
    "Solid Gold Lil Uzi Vert",
    "Lil' Uzi Crew",
    "London",
    "So Kawaii",
    "Gold Cadillac Blackwing"
)

@Composable
fun RewardsScreen() {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(query, { query = it }, label = { Text("Buscar recompensa") },
            modifier = Modifier.fillMaxWidth())
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(rewardNames.filter { it.contains(query, ignoreCase = true) }) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel),
                    onClick = { selected = item }) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CardGiftcard, null, tint = Blue)
                        Spacer(Modifier.width(10.dp))
                        Text(item, color = Color.White)
                    }
                }
            }
        }
        if (selected.isNotBlank()) {
            PanelCard("Recompensa selecionada") {
                Text(selected)
                Text("Cadastro inicial. Confirme a disponibilidade e a distribuição no Fortnite.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun DiscordScreen() {
    var webhook by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Webhook ainda não configurado.") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        PanelCard("Discord Webhook") {
            OutlinedTextField(webhook, { webhook = it }, label = { Text("URL do Webhook") },
                modifier = Modifier.fillMaxWidth())
            Text("Mantenha esta URL privada. Não compartilhe capturas de tela que a mostrem.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Button(onClick = { message = "Protótipo: envio real ainda não implementado." }) {
                Text("Testar conexão")
            }
            Text(message, color = Muted)
        }
        PanelCard("Notificações") {
            listOf("Nova recompensa", "Partida encerrada", "Resumo da sessão", "Erro de reconhecimento").forEach {
                var checked by remember { mutableStateOf(true) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked, { checked = it })
                    Text(it, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun HistoryScreen() {
    PanelCard("Histórico de atividades") {
        Text("Nenhuma atividade registrada ainda.", color = Muted)
        Text("Esta versão é um protótipo de interface; persistência local e integração com dados do jogo ainda precisam ser implementadas.", color = Muted, fontSize = 12.sp)
    }
}
