# Fortnite AFK Manager — Android companion

Projeto Android em Kotlin + Jetpack Compose, preparado para abrir no Android Studio.

## Incluído
- Dashboard inicial.
- Navegação por cinco áreas.
- Configurações visuais de limite de partidas, temporizador e intervalo.
- Catálogo inicial com 18 nomes de recompensas.
- Tela demonstrativa de configuração do Discord.
- Mini painel flutuante demonstrativo, ativado manualmente.
- Tema escuro azul/preto.

## Limites desta versão
Este é um companion/protótipo. Não automatiza toques, movimentos, entrada ou saída de partidas, não tenta evitar detecção AFK/anticheat, não lê automaticamente dados privados do Fortnite, não faz OCR em tempo real, não envia Webhook real e não mantém histórico persistente. Estados do squad devem ser informados manualmente; sem confirmação, use “Desconhecido”.

## Requisitos
- JDK 17
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Gradle 8.9
- Android Gradle Plugin 8.7.2
- Kotlin 2.1.10

Abra a pasta `FortniteAFKManager` no Android Studio. O workflow do GitHub Actions compila o APK de depuração e o publica como artefato.
